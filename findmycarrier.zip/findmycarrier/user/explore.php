<?php
require_once "../config/db.php";
protect();
$username = $_SESSION['username'] ?? '';

// Fetch filter inputs
$search = $_GET['search'] ?? '';
$location = $_GET['location'] ?? '';
$job_type = $_GET['job_type'] ?? '';
$skills = $_GET['skills'] ?? '';
$experience = $_GET['experience'] ?? '';
$sort = $_GET['sort'] ?? 'recent';

// Build dynamic query
$query = "SELECT * FROM jobs WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND (title LIKE ? OR company LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($location) {
    $query .= " AND location LIKE ?";
    $params[] = "%$location%";
}
if ($job_type) {
    $query .= " AND type = ?";
    $params[] = $job_type;
}
if ($skills) {
    $query .= " AND skills LIKE ?";
    $params[] = "%$skills%";
}
if ($experience) {
    $query .= " AND experience = ?";
    $params[] = $experience;
}

// Sorting
if ($sort === 'recent') {
    $query .= " ORDER BY posted_date DESC";
} elseif ($sort === 'salary') {
    $query .= " ORDER BY salary DESC";
}

// Execute query
$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Query failed: " . $conn->error);
}
if ($params) {
    $types = str_repeat('s', count($params));
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$jobs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<?php get_head("Explore Jobs - Find My Career"); ?>

<body class="min-h-screen flex flex-col bg-gray-50 text-gray-800">
  <div class="flex flex-col md:flex-row w-full">
    <!-- Sidebar -->
    <?php include("./includes/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-4 md:p-6 w-full overflow-y-auto">
      <!-- Welcome Section -->
      <section class="mb-6">
        <h2 class="text-3xl text-gray-800">Explore Jobs for You</h2>
        <p class="text-gray-600 text-sm mt-1">Discover entry-level jobs and internships perfect for students like you!</p>
      </section>

      <!-- Filters Section -->
      <section class="mb-6 bg-white p-4 rounded-lg shadow-sm">
        <form class="flex flex-col md:flex-row gap-4" method="GET">
          <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search jobs, companies, or keywords..." class="p-2 border rounded-md w-full md:w-1/4 focus:ring-2 focus:ring-blue-500">
          <input type="text" name="location" value="<?= htmlspecialchars($location) ?>" placeholder="Location (e.g., Bangalore, Remote)" class="p-2 border rounded-md w-full md:w-1/5 focus:ring-2 focus:ring-blue-500">
          <select name="job_type" class="p-2 border rounded-md w-full md:w-1/5 focus:ring-2 focus:ring-blue-500">
            <option value="">All Job Types</option>
            <option value="full-time" <?= $job_type === 'full-time' ? 'selected' : '' ?>>Full-Time</option>
            <option value="part-time" <?= $job_type === 'part-time' ? 'selected' : '' ?>>Part-Time</option>
            <option value="internship" <?= $job_type === 'internship' ? 'selected' : '' ?>>Internship</option>
            <option value="freelance" <?= $job_type === 'freelance' ? 'selected' : '' ?>>Freelance</option>
          </select>
          <input type="text" name="skills" value="<?= htmlspecialchars($skills) ?>" placeholder="Skills (e.g., HTML, Writing)" class="p-2 border rounded-md w-full md:w-1/5 focus:ring-2 focus:ring-blue-500">
          <select name="experience" class="p-2 border rounded-md w-full md:w-1/5 focus:ring-2 focus:ring-blue-500">
            <option value="">All Experience Levels</option>
            <option value="None" <?= $experience === 'None' ? 'selected' : '' ?>>No Experience</option>
            <option value="0-1 year" <?= $experience === '0-1 year' ? 'selected' : '' ?>>0-1 Year</option>
          </select>
          <select name="sort" class="p-2 border rounded-md w-full md:w-1/5 focus:ring-2 focus:ring-blue-500">
            <option value="recent" <?= $sort === 'recent' ? 'selected' : '' ?>>Most Recent</option>
            <option value="salary" <?= $sort === 'salary' ? 'selected' : '' ?>>Highest Salary</option>
          </select>
          <button type="submit" class="p-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition w-full md:w-auto">Apply Filters</button>
        </form>
      </section>

      <!-- Job Cards -->
      <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <?php if (empty($jobs)): ?>
          <p class="text-gray-600 col-span-full text-center">No jobs found. Try adjusting your filters or check back later!</p>
        <?php else: ?>
          <?php foreach ($jobs as $job): ?>
            <div class="border rounded-lg p-4 bg-white shadow-sm hover:shadow-lg transition transform hover:-translate-y-1">
              <h3 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($job['title']) ?></h3>
              <p class="text-gray-600 text-sm"><?= htmlspecialchars($job['company']) ?></p>
              <div class="text-gray-500 text-sm mt-2 space-y-1">
                <p><span class="font-medium">Location:</span> <?= htmlspecialchars($job['location']) ?></p>
                <p><span class="font-medium">Type:</span> <?= htmlspecialchars(ucfirst($job['type'])) ?></p>
                <p><span class="font-medium">Salary:</span> <?= $job['salary'] ? '₹' . number_format($job['salary']) : 'Not disclosed' ?></p>
                <p><span class="font-medium">Skills:</span> <?= htmlspecialchars($job['skills']) ?></p>
                <p><span class="font-medium">Education:</span> <?= htmlspecialchars($job['education']) ?></p>
                <p><span class="font-medium">Experience:</span> <?= htmlspecialchars($job['experience']) ?></p>
              </div>
              <p class="text-gray-400 text-xs mt-2">Posted: <?= date('M d, Y', strtotime($job['posted_date'])) ?></p>
              <p class="text-gray-600 text-sm mt-2 line-clamp-2"><?= htmlspecialchars($job['description']) ?></p>
              <a href="job-details.php?id=<?= $job['id'] ?>" class="mt-3 inline-block text-blue-600 hover:underline font-medium">View Details</a>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>
    </main>
  </div>

  <?php include("includes/bottom.php"); ?>
</body>
