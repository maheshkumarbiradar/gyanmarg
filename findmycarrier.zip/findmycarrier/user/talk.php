<?php
require_once "../config/db.php";
protect();
$username = $_SESSION['username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<?php get_head("talk - Find My Career"); ?>

<body class="min-h-screen flex flex-col bg-white text-gray-800">

  <div class="flex flex-col md:flex-row w-full">
    <!-- Sidebar -->
    <?php include("./includes/sidebar.php"); ?>

    <!-- Main Content -->
    <main class="flex-1 p-4 md:p-6 w-full overflow-y-auto">
      <!-- Welcome Section -->
      <section class="mb-6 ">
        <h2 class="text-3xl text-gray-800">Talk to AI</h2>
        <p class="text-gray-600 text-sm mt-1">Clear all your questions with our AI</p>
      </section>
      <div class="w-full h-screen p-2">
        <iframe
          src="https://9000-firebase-studio-1747335856452.cluster-73qgvk7hjjadkrjeyexca5ivva.cloudworkstations.dev"
          class="w-full h-full border-0"></iframe>
      </div>
    </main>
  </div>

  <?php include("includes/bottom.php"); ?>
</body>

<style>
  html {
    font-family: -apple-system, BlinkMacSystemFont, "San Francisco", "Helvetica Neue", Helvetica, Arial, sans-serif;
  }
</style>

</html>
